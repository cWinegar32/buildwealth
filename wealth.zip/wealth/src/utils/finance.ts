import type { BudgetState, GoalInputs, GoalResult, LedgerItem, TrajectoryPoint } from '@/types';

/**
 * All financial math lives here. Conventions:
 *  - Rates are passed in percent (7 = 7%).
 *  - The annual return is treated as an effective annual rate, converted to an equivalent
 *    monthly rate, so 7% for 12 months grows $1 to exactly $1.07.
 *  - Contributions are made at the END of each month.
 *  - Returns are constant. Real markets are not; see the disclaimers in the UI.
 */

const MAX_MONTHS = 100 * 12;

export function monthlyRate(annualPct: number): number {
  return Math.pow(1 + annualPct / 100, 1 / 12) - 1;
}

/** Balance after `months` of growth plus a level monthly contribution. */
export function futureValue(start: number, monthly: number, annualPct: number, months: number): number {
  if (months <= 0) return start;
  const r = monthlyRate(annualPct);
  if (Math.abs(r) < 1e-12) return start + monthly * months;
  const growth = Math.pow(1 + r, months);
  return start * growth + monthly * ((growth - 1) / r);
}

/** Level monthly contribution needed to reach `target` in `months`. Never negative. */
export function requiredMonthly(target: number, start: number, annualPct: number, months: number): number {
  if (months <= 0) return Math.max(0, target - start);
  const r = monthlyRate(annualPct);
  const growth = Math.pow(1 + r, months);
  const gap = target - start * growth;
  if (gap <= 0) return 0;
  const annuityFactor = Math.abs(r) < 1e-12 ? months : (growth - 1) / r;
  return gap / annuityFactor;
}

export function inflate(value: number, inflationPct: number, years: number): number {
  return value * Math.pow(1 + inflationPct / 100, years);
}

export function deflate(value: number, inflationPct: number, years: number): number {
  return value / Math.pow(1 + inflationPct / 100, years);
}

/** Month-by-month balances, sampled at every 12th month plus the final month. */
export function projectTrajectory(
  start: number,
  monthly: number,
  annualPct: number,
  months: number,
): TrajectoryPoint[] {
  const r = monthlyRate(annualPct);
  const points: TrajectoryPoint[] = [{ month: 0, year: 0, balance: start, contributed: start }];
  let balance = start;
  for (let m = 1; m <= months; m++) {
    balance = balance * (1 + r) + monthly;
    if (m % 12 === 0 || m === months) {
      points.push({ month: m, year: m / 12, balance, contributed: start + monthly * m });
    }
  }
  return points;
}

/** First month at which the balance reaches `target`, or null if not within 100 years. */
export function monthsToTarget(target: number, start: number, monthly: number, annualPct: number): number | null {
  if (start >= target) return 0;
  const r = monthlyRate(annualPct);
  let balance = start;
  for (let m = 1; m <= MAX_MONTHS; m++) {
    balance = balance * (1 + r) + monthly;
    if (balance >= target) return m;
  }
  return null;
}

export function evaluateGoal(input: GoalInputs): GoalResult {
  const months = Math.max(1, Math.round(input.years * 12));
  const years = months / 12;
  const nominalTarget = input.todaysDollars ? inflate(input.targetAmount, input.inflationPct, years) : input.targetAmount;
  const projectedBalance = futureValue(input.startingBalance, input.monthlyContribution, input.annualReturnPct, months);
  const totalContributed = input.startingBalance + input.monthlyContribution * months;
  const shortfall = nominalTarget - projectedBalance;
  return {
    months,
    nominalTarget,
    requiredMonthly: requiredMonthly(nominalTarget, input.startingBalance, input.annualReturnPct, months),
    projectedBalance,
    totalContributed,
    growth: projectedBalance - totalContributed,
    shortfall,
    onPace: shortfall <= 0.5,
    monthsToTarget: monthsToTarget(nominalTarget, input.startingBalance, input.monthlyContribution, input.annualReturnPct),
    trajectory: projectTrajectory(input.startingBalance, input.monthlyContribution, input.annualReturnPct, months),
  };
}

/* ----------------------------- Budgeting ----------------------------- */

export const RULE_50_30_20 = { needsPct: 50, wantsPct: 30, savingsPct: 20 } as const;

export function allocateBudget(b: Pick<BudgetState, 'income' | 'needsPct' | 'wantsPct' | 'savingsPct'>) {
  const totalPct = b.needsPct + b.wantsPct + b.savingsPct;
  return {
    needs: (b.income * b.needsPct) / 100,
    wants: (b.income * b.wantsPct) / 100,
    savings: (b.income * b.savingsPct) / 100,
    totalPct,
    balanced: Math.abs(totalPct - 100) < 0.01,
  };
}

/* ----------------------------- Net worth ----------------------------- */

export function sumItems(items: LedgerItem[]): number {
  return items.reduce((sum, i) => sum + (Number.isFinite(i.amount) ? i.amount : 0), 0);
}

export function breakdownByCategory(items: LedgerItem[]): { label: string; value: number }[] {
  const map = new Map<string, number>();
  for (const i of items) map.set(i.category, (map.get(i.category) ?? 0) + (Number.isFinite(i.amount) ? i.amount : 0));
  return [...map.entries()]
    .map(([label, value]) => ({ label, value }))
    .filter((s) => s.value > 0)
    .sort((a, b) => b.value - a.value);
}
