const usd0 = new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 });
const usdCompact = new Intl.NumberFormat('en-US', {
  style: 'currency',
  currency: 'USD',
  notation: 'compact',
  maximumFractionDigits: 1,
});

export function currency(n: number): string {
  if (!Number.isFinite(n)) return '—';
  return usd0.format(Math.round(n));
}

export function currencyCompact(n: number): string {
  if (!Number.isFinite(n)) return '—';
  return usdCompact.format(n);
}

export function percent(n: number, digits = 0): string {
  return `${n.toFixed(digits)}%`;
}

export function duration(months: number): string {
  const y = Math.floor(months / 12);
  const m = months % 12;
  const parts: string[] = [];
  if (y > 0) parts.push(`${y} ${y === 1 ? 'year' : 'years'}`);
  if (m > 0) parts.push(`${m} ${m === 1 ? 'month' : 'months'}`);
  return parts.length ? parts.join(' ') : '0 months';
}

export function uid(): string {
  return Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
}
