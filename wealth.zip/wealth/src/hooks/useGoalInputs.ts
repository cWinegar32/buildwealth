import { defaultGoal, isGoalInputs } from '@/data/goals';
import type { GoalInputs } from '@/types';
import { useLocalStorage } from './useLocalStorage';

const INITIAL = defaultGoal('home');

/** Shared goal settings: the Home preview, Quick-start and the full estimator all read this. */
export function useGoalInputs() {
  return useLocalStorage<GoalInputs>('wealth.goal.v1', INITIAL, isGoalInputs);
}
