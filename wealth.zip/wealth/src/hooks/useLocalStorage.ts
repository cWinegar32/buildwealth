import { useCallback, useEffect, useState } from 'react';

/**
 * useState that persists to localStorage. Safe when storage is blocked or the stored value is
 * corrupt: it falls back to `initial`. `validate` lets a caller reject shapes from older versions.
 */
export function useLocalStorage<T>(
  key: string,
  initial: T,
  validate?: (value: unknown) => value is T,
): [T, (next: T | ((prev: T) => T)) => void, () => void] {
  const [value, setValue] = useState<T>(() => {
    try {
      const raw = window.localStorage.getItem(key);
      if (raw === null) return initial;
      const parsed: unknown = JSON.parse(raw);
      if (validate ? validate(parsed) : true) return parsed as T;
    } catch {
      /* storage unavailable or corrupt: use defaults */
    }
    return initial;
  });

  useEffect(() => {
    try {
      window.localStorage.setItem(key, JSON.stringify(value));
    } catch {
      /* ignore quota / privacy-mode errors */
    }
  }, [key, value]);

  const reset = useCallback(() => setValue(initial), [initial]);
  return [value, setValue, reset];
}
