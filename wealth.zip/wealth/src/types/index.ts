export type GoalPresetId = 'retirement' | 'home' | 'milestone' | 'emergency';

export interface GoalInputs {
  presetId: GoalPresetId;
  /** Target amount. Interpreted in today's dollars when `todaysDollars` is true. */
  targetAmount: number;
  years: number;
  startingBalance: number;
  monthlyContribution: number;
  /** Expected nominal annual return, in percent (e.g. 7 = 7%). */
  annualReturnPct: number;
  /** Assumed annual inflation, in percent. */
  inflationPct: number;
  todaysDollars: boolean;
}

export interface TrajectoryPoint {
  month: number;
  year: number;
  balance: number;
  contributed: number;
}

export interface GoalResult {
  months: number;
  /** Target in future (nominal) dollars at the goal date. */
  nominalTarget: number;
  requiredMonthly: number;
  projectedBalance: number;
  totalContributed: number;
  growth: number;
  /** nominalTarget - projectedBalance. Positive = behind, negative = ahead. */
  shortfall: number;
  onPace: boolean;
  /** Months until the target is reached at the current contribution, or null if > 100 years. */
  monthsToTarget: number | null;
  trajectory: TrajectoryPoint[];
}

export type BudgetMethod = '50-30-20' | 'custom';

export interface BudgetState {
  income: number;
  method: BudgetMethod;
  needsPct: number;
  wantsPct: number;
  savingsPct: number;
}

export interface LedgerItem {
  id: string;
  name: string;
  amount: number;
  category: string;
}

export interface TrackerState {
  assets: LedgerItem[];
  liabilities: LedgerItem[];
}

export interface LessonSection {
  heading: string;
  body: string[];
}

export interface Lesson {
  id: string;
  title: string;
  summary: string;
  minutes: number;
  sections: LessonSection[];
  takeaways: string[];
  illustration?: 'compounding';
}

export type RoadmapStatus = 'live' | 'next' | 'later';

export interface RoadmapItem {
  title: string;
  description: string;
  status: RoadmapStatus;
}

export interface ToolMeta {
  slug: string;
  title: string;
  tagline: string;
  scope: string;
  live: string;
  next: string;
}
