import type { ReactNode } from 'react';

export function PageHeader({ title, intro, children }: { title: string; intro: string; children?: ReactNode }) {
  return (
    <header className="border-b border-line">
      <div className="mx-auto max-w-page px-5 pb-10 pt-12 sm:px-8 sm:pb-14 sm:pt-16">
        <h1 className="max-w-3xl text-4xl font-semibold leading-[1.08] tracking-display sm:text-5xl">{title}</h1>
        <p className="mt-5 max-w-2xl text-lg leading-relaxed text-muted">{intro}</p>
        {children}
      </div>
    </header>
  );
}

export function Section({ children, className = '' }: { children: ReactNode; className?: string }) {
  return <section className={`mx-auto max-w-page px-5 py-14 sm:px-8 sm:py-20 ${className}`}>{children}</section>;
}

export function Disclaimer({ children }: { children: ReactNode }) {
  return <p className="rounded-lg bg-warn-soft px-4 py-3 text-xs leading-relaxed text-warn">{children}</p>;
}
