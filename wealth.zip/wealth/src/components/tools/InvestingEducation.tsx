import { useState } from 'react';
import { RangeField } from '@/components/ui/Field';
import { Disclaimer } from '@/components/ui/PageHeader';
import { LESSONS } from '@/data/lessons';
import type { Lesson } from '@/types';
import { futureValue } from '@/utils/finance';
import { currency } from '@/utils/format';

const ILLUSTRATION_RETURN = 7;
const HORIZONS = [10, 20, 30, 40];

function CompoundingIllustration() {
  const [monthly, setMonthly] = useState(200);
  return (
    <div className="mt-6 rounded-xl border border-line bg-bg p-5">
      <p className="text-sm font-medium">See it with your own number</p>
      <div className="mt-4 max-w-sm">
        <RangeField label="Invest each month" min={25} max={1000} step={25} value={monthly} format={currency} onChange={setMonthly} />
      </div>
      <div className="mt-5 overflow-x-auto">
        <table className="w-full min-w-[22rem] text-left text-sm">
          <caption className="sr-only">Balance after different time periods at a steady {ILLUSTRATION_RETURN}% yearly return</caption>
          <thead>
            <tr className="border-b border-line text-muted">
              <th scope="col" className="py-2 pr-4 font-normal">After</th>
              <th scope="col" className="py-2 pr-4 font-normal">You put in</th>
              <th scope="col" className="py-2 pr-4 font-normal">Balance</th>
              <th scope="col" className="py-2 font-normal">Growth share</th>
            </tr>
          </thead>
          <tbody className="num">
            {HORIZONS.map((y) => {
              const put = monthly * y * 12;
              const bal = futureValue(0, monthly, ILLUSTRATION_RETURN, y * 12);
              return (
                <tr key={y} className="border-b border-line last:border-0">
                  <th scope="row" className="py-2.5 pr-4 font-normal">{y} years</th>
                  <td className="py-2.5 pr-4">{currency(put)}</td>
                  <td className="py-2.5 pr-4 font-medium">{currency(bal)}</td>
                  <td className="py-2.5">{Math.round(((bal - put) / bal) * 100)}%</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      <p className="mt-3 text-xs leading-relaxed text-muted">
        Illustration only: a steady {ILLUSTRATION_RETURN}% yearly return, deposits at month-end, no fees, taxes or inflation. Real returns vary.
      </p>
    </div>
  );
}

function LessonItem({ lesson, defaultOpen }: { lesson: Lesson; defaultOpen: boolean }) {
  return (
    <details className="group border-b border-line py-1" open={defaultOpen}>
      <summary className="flex cursor-pointer items-start justify-between gap-6 py-4">
        <div>
          <h3 className="text-lg font-semibold">{lesson.title}</h3>
          <p className="mt-1 text-sm text-muted">{lesson.summary}</p>
        </div>
        <span className="num shrink-0 pt-1 text-sm text-muted">
          {lesson.minutes} min <span aria-hidden="true" className="ml-2 inline-block transition-transform group-open:rotate-45">+</span>
        </span>
      </summary>
      <div className="max-w-2xl pb-6">
        {lesson.sections.map((s) => (
          <div key={s.heading} className="mt-5 first:mt-0">
            <h4 className="font-medium">{s.heading}</h4>
            {s.body.map((p) => (
              <p key={p} className="mt-2 leading-relaxed text-muted">{p}</p>
            ))}
          </div>
        ))}
        {lesson.illustration === 'compounding' && <CompoundingIllustration />}
        <div className="mt-6 rounded-lg bg-accent-soft px-4 py-3">
          <p className="text-sm font-medium text-accent">Key takeaways</p>
          <ul className="mt-2 list-disc space-y-1 pl-5 text-sm text-ink">
            {lesson.takeaways.map((t) => (
              <li key={t}>{t}</li>
            ))}
          </ul>
        </div>
      </div>
    </details>
  );
}

export function InvestingEducation() {
  return (
    <div className="max-w-3xl">
      <div className="border-t border-line">
        {LESSONS.map((l, i) => (
          <LessonItem key={l.id} lesson={l} defaultOpen={i === 0} />
        ))}
      </div>
      <div className="mt-8">
        <Disclaimer>
          General education, not a recommendation to buy or sell anything. Investments can lose value. Tax rules described here are US-focused and change; verify with the IRS or a qualified professional.
        </Disclaimer>
      </div>
    </div>
  );
}
