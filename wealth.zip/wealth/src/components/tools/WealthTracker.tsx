import { SegmentedBar } from '@/components/charts/SegmentedBar';
import { Button } from '@/components/ui/Button';
import { NumberField, SelectField } from '@/components/ui/Field';
import { useLocalStorage } from '@/hooks/useLocalStorage';
import type { LedgerItem, TrackerState } from '@/types';
import { breakdownByCategory, sumItems } from '@/utils/finance';
import { currency, uid } from '@/utils/format';

const ASSET_CATEGORIES = ['Cash', 'Investments', 'Retirement', 'Property', 'Other'];
const LIABILITY_CATEGORIES = ['Student loan', 'Credit card', 'Auto loan', 'Mortgage', 'Other'];

const SAMPLE: TrackerState = {
  assets: [
    { id: 'a1', name: 'Checking account', amount: 2400, category: 'Cash' },
    { id: 'a2', name: 'High-yield savings', amount: 5200, category: 'Cash' },
    { id: 'a3', name: 'Workplace 401(k)', amount: 7800, category: 'Retirement' },
    { id: 'a4', name: 'Brokerage account', amount: 1500, category: 'Investments' },
  ],
  liabilities: [
    { id: 'l1', name: 'Student loan', amount: 14500, category: 'Student loan' },
    { id: 'l2', name: 'Credit card', amount: 900, category: 'Credit card' },
  ],
};

function isLedger(items: unknown): items is LedgerItem[] {
  return (
    Array.isArray(items) &&
    items.every(
      (i) =>
        typeof i === 'object' &&
        i !== null &&
        typeof i.id === 'string' &&
        typeof i.name === 'string' &&
        typeof i.category === 'string' &&
        typeof i.amount === 'number' &&
        Number.isFinite(i.amount),
    )
  );
}
function isTracker(v: unknown): v is TrackerState {
  return typeof v === 'object' && v !== null && isLedger((v as TrackerState).assets) && isLedger((v as TrackerState).liabilities);
}

export function WealthTracker() {
  const [state, setState, reset] = useLocalStorage<TrackerState>('wealth.tracker.v1', SAMPLE, isTracker);
  const totalAssets = sumItems(state.assets);
  const totalLiabilities = sumItems(state.liabilities);
  const netWorth = totalAssets - totalLiabilities;

  const update = (side: keyof TrackerState) => (items: LedgerItem[]) => setState((s) => ({ ...s, [side]: items }));

  return (
    <div className="space-y-12">
      <div className="grid gap-8 border-b border-line pb-10 lg:grid-cols-[minmax(0,5fr)_minmax(0,7fr)] lg:gap-14">
        <div>
          <p className="text-sm text-muted">Net worth</p>
          <p className={`num mt-1 text-5xl font-semibold tracking-display sm:text-6xl ${netWorth < 0 ? 'text-warn' : ''}`}>{currency(netWorth)}</p>
          <dl className="mt-5 flex gap-8 text-sm">
            <div>
              <dt className="text-muted">Assets</dt>
              <dd className="num mt-0.5 text-lg font-medium">{currency(totalAssets)}</dd>
            </div>
            <div>
              <dt className="text-muted">Liabilities</dt>
              <dd className="num mt-0.5 text-lg font-medium">{currency(totalLiabilities)}</dd>
            </div>
          </dl>
          {netWorth < 0 && (
            <p className="mt-4 text-sm leading-relaxed text-muted">
              A negative net worth is common early on, especially with student loans. The goal is the direction over time, not the starting number.
            </p>
          )}
        </div>
        <div className="min-w-0 self-end">
          <p className="mb-3 text-sm font-medium">Where your assets sit</p>
          <SegmentedBar label="Asset allocation" segments={breakdownByCategory(state.assets)} />
        </div>
      </div>

      <div className="grid gap-12 lg:grid-cols-2 lg:gap-14">
        <Ledger title="Assets" addLabel="Add asset" categories={ASSET_CATEGORIES} items={state.assets} onChange={update('assets')} />
        <Ledger title="Liabilities" addLabel="Add liability" categories={LIABILITY_CATEGORIES} items={state.liabilities} onChange={update('liabilities')} />
      </div>

      <div className="flex flex-col gap-3 border-t border-line pt-6 text-sm text-muted sm:flex-row sm:items-center sm:justify-between">
        <p>Sample numbers to start. Everything you enter is saved only in this browser.</p>
        <div className="flex gap-2">
          <Button variant="secondary" onClick={reset}>
            Reset to sample
          </Button>
          <Button variant="secondary" onClick={() => setState({ assets: [], liabilities: [] })}>
            Clear all
          </Button>
        </div>
      </div>
    </div>
  );
}

interface LedgerProps {
  title: string;
  addLabel: string;
  categories: string[];
  items: LedgerItem[];
  onChange: (items: LedgerItem[]) => void;
}

function Ledger({ title, addLabel, categories, items, onChange }: LedgerProps) {
  const patch = (id: string, p: Partial<LedgerItem>) => onChange(items.map((i) => (i.id === id ? { ...i, ...p } : i)));
  return (
    <section aria-labelledby={`ledger-${title}`}>
      <div className="mb-4 flex items-baseline justify-between">
        <h3 id={`ledger-${title}`} className="text-lg font-semibold">
          {title}
        </h3>
        <p className="num text-sm text-muted">{currency(sumItems(items))}</p>
      </div>
      {items.length === 0 ? (
        <p className="rounded-lg border border-dashed border-line px-4 py-6 text-center text-sm text-muted">
          Nothing here yet. Add your first {title.toLowerCase().slice(0, -1)}.
        </p>
      ) : (
        <ul className="divide-y divide-line border-y border-line">
          {items.map((item) => (
            <li key={item.id} className="grid grid-cols-[1fr_auto] items-end gap-x-3 gap-y-2 py-3 sm:grid-cols-[1fr_8.5rem_7rem_auto]">
              <div className="col-span-2 sm:col-span-1">
                <label className="sr-only" htmlFor={`n-${item.id}`}>
                  Name
                </label>
                <input id={`n-${item.id}`} className="input" value={item.name} onChange={(e) => patch(item.id, { name: e.target.value })} placeholder="Name" />
              </div>
              <SelectField label="Category" hideLabel value={item.category} options={categories} onChange={(v) => patch(item.id, { category: v })} />
              <NumberField label={`${item.name || 'Item'} amount`} hideLabel prefix="$" min={0} value={item.amount} onChange={(n) => patch(item.id, { amount: n })} />
              <button
                type="button"
                className="h-[38px] rounded-lg px-2 text-sm text-muted hover:bg-ink/5 hover:text-ink"
                aria-label={`Remove ${item.name || 'item'}`}
                onClick={() => onChange(items.filter((i) => i.id !== item.id))}
              >
                Remove
              </button>
            </li>
          ))}
        </ul>
      )}
      <Button
        variant="secondary"
        className="mt-4"
        onClick={() => onChange([...items, { id: uid(), name: '', amount: 0, category: categories[0] }])}
      >
        {addLabel}
      </Button>
    </section>
  );
}
