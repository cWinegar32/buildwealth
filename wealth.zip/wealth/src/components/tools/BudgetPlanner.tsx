import { useNavigate } from 'react-router-dom';
import { SegmentedBar } from '@/components/charts/SegmentedBar';
import { Button } from '@/components/ui/Button';
import { NumberField, RangeField, Segmented } from '@/components/ui/Field';
import { useGoalInputs } from '@/hooks/useGoalInputs';
import { useLocalStorage } from '@/hooks/useLocalStorage';
import type { BudgetMethod, BudgetState } from '@/types';
import { RULE_50_30_20, allocateBudget } from '@/utils/finance';
import { currency } from '@/utils/format';

const INITIAL: BudgetState = { income: 3800, method: '50-30-20', ...RULE_50_30_20 };

function isBudget(v: unknown): v is BudgetState {
  if (typeof v !== 'object' || v === null) return false;
  const b = v as Record<string, unknown>;
  return (
    (b.method === '50-30-20' || b.method === 'custom') &&
    ['income', 'needsPct', 'wantsPct', 'savingsPct'].every((k) => typeof b[k] === 'number' && Number.isFinite(b[k] as number))
  );
}

const ROWS = [
  { key: 'needsPct', label: 'Needs', hint: 'Rent, utilities, groceries, transport, insurance, minimum debt payments.', out: 'needs' },
  { key: 'wantsPct', label: 'Wants', hint: 'Eating out, subscriptions, travel, hobbies, anything you could pause.', out: 'wants' },
  { key: 'savingsPct', label: 'Savings and extra debt payoff', hint: 'Emergency fund, investing, and payments above the minimum.', out: 'savings' },
] as const;

export function BudgetPlanner() {
  const [budget, setBudget] = useLocalStorage<BudgetState>('wealth.budget.v1', INITIAL, isBudget);
  const [, setGoal] = useGoalInputs();
  const navigate = useNavigate();
  const alloc = allocateBudget(budget);

  const setMethod = (method: BudgetMethod) =>
    setBudget((b) => (method === '50-30-20' ? { ...b, method, ...RULE_50_30_20 } : { ...b, method }));
  const setPct = (key: (typeof ROWS)[number]['key'], value: number) => setBudget((b) => ({ ...b, method: 'custom', [key]: value }));

  const sendToGoal = () => {
    setGoal((g) => ({ ...g, monthlyContribution: Math.round(alloc.savings / 25) * 25 }));
    navigate('/tools/goal-pace');
  };

  return (
    <div className="grid gap-10 lg:grid-cols-[minmax(0,5fr)_minmax(0,7fr)] lg:gap-14">
      <div className="space-y-6">
        <NumberField
          label="Monthly take-home pay"
          prefix="$"
          min={0}
          value={budget.income}
          onChange={(n) => setBudget((b) => ({ ...b, income: n }))}
          hint="After taxes. If your income varies, enter your lowest month from the last six."
        />
        <div>
          <p className="mb-1.5 text-sm font-medium">Method</p>
          <Segmented
            label="Budget method"
            value={budget.method}
            options={[
              { value: '50-30-20', label: '50 / 30 / 20' },
              { value: 'custom', label: 'Custom' },
            ]}
            onChange={setMethod}
          />
          <p className="mt-2 text-xs leading-relaxed text-muted">
            50/30/20 is a starting point, not a rule. In expensive cities, needs often take more than half. Drag a slider to make it your own.
          </p>
        </div>
        <div className="space-y-5 border-t border-line pt-5">
          {ROWS.map((r) => (
            <RangeField key={r.key} label={r.label} min={0} max={100} value={budget[r.key]} format={(n) => `${n}%`} onChange={(n) => setPct(r.key, n)} />
          ))}
          <p className={`text-sm ${alloc.balanced ? 'text-accent' : 'text-warn'}`} role="status">
            {alloc.balanced
              ? 'Your split adds up to 100%.'
              : `Your split adds up to ${alloc.totalPct}%. ${alloc.totalPct > 100 ? 'Reduce' : 'Assign'} ${Math.abs(100 - alloc.totalPct)}% to balance it.`}
          </p>
        </div>
      </div>

      <div className="min-w-0 space-y-8">
        <SegmentedBar
          label="Budget split"
          segments={ROWS.map((r) => ({ label: r.label.split(' ')[0], value: alloc[r.out] }))}
        />
        <ul className="divide-y divide-line border-y border-line">
          {ROWS.map((r) => (
            <li key={r.key} className="flex items-start justify-between gap-6 py-4">
              <div className="min-w-0">
                <p className="font-medium">
                  {r.label} <span className="num text-muted">{budget[r.key]}%</span>
                </p>
                <p className="mt-0.5 text-sm text-muted">{r.hint}</p>
              </div>
              <p className="num shrink-0 text-xl font-medium">{currency(alloc[r.out])}</p>
            </li>
          ))}
        </ul>

        <div className="rounded-xl border border-line bg-surface p-5">
          <p className="font-medium">Put your savings to work</p>
          <p className="mt-1 text-sm text-muted">
            {currency(alloc.savings)} a month is your savings line. Send it to the Goal Pace Estimator to see where it gets you.
          </p>
          <Button className="mt-4" onClick={sendToGoal}>
            Use as monthly contribution
          </Button>
        </div>

        <div className="border-l-2 border-line pl-4">
          <p className="text-sm font-medium">Coming next: monthly tracker</p>
          <p className="mt-1 text-sm leading-relaxed text-muted">
            Log what you actually spend, compare it with this plan, and use a variable-income mode that budgets from your lowest recent month.
          </p>
        </div>
      </div>
    </div>
  );
}
