import { Link } from 'react-router-dom';
import { TrajectoryChart } from '@/components/charts/TrajectoryChart';
import { NumberField, RangeField, Segmented } from '@/components/ui/Field';
import { Disclaimer } from '@/components/ui/PageHeader';
import { GOAL_PRESETS, defaultGoal, getPreset } from '@/data/goals';
import { useGoalInputs } from '@/hooks/useGoalInputs';
import type { GoalInputs, GoalPresetId } from '@/types';
import { deflate, evaluateGoal } from '@/utils/finance';
import { currency, duration } from '@/utils/format';

interface Props {
  variant?: 'full' | 'compact';
}

export function GoalPaceCalculator({ variant = 'full' }: Props) {
  const [goal, setGoal] = useGoalInputs();
  const compact = variant === 'compact';
  const result = evaluateGoal(goal);
  const set = <K extends keyof GoalInputs>(key: K, value: GoalInputs[K]) => setGoal((g) => ({ ...g, [key]: value }));
  const preset = getPreset(goal.presetId);
  const years = result.months / 12;
  const yearsLabel = Number.isInteger(years) ? `${years}` : years.toFixed(1);

  const gap = Math.round(result.requiredMonthly - goal.monthlyContribution);
  const projectedToday = deflate(result.projectedBalance, goal.inflationPct, years);

  const summary = `Projected balance grows from ${currency(goal.startingBalance)} to ${currency(result.projectedBalance)} over ${yearsLabel} years, against a goal of ${currency(result.nominalTarget)}.`;

  return (
    <div className={compact ? '' : 'grid gap-10 lg:grid-cols-[minmax(0,5fr)_minmax(0,7fr)] lg:gap-14'}>
      {/* Inputs */}
      <div className="space-y-5">
        <div>
          <label className="mb-1.5 block text-sm font-medium" htmlFor={`goal-preset-${variant}`}>
            Goal
          </label>
          <select
            id={`goal-preset-${variant}`}
            className="input"
            value={goal.presetId}
            onChange={(e) => setGoal(defaultGoal(e.target.value as GoalPresetId))}
          >
            {GOAL_PRESETS.map((p) => (
              <option key={p.id} value={p.id}>
                {p.label}
              </option>
            ))}
          </select>
          {!compact && <p className="mt-1.5 text-xs text-muted">{preset.description} Changing the goal loads its starter assumptions.</p>}
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <NumberField label="Target amount" prefix="$" min={0} value={goal.targetAmount} onChange={(n) => set('targetAmount', n)} />
          <NumberField label="Starting balance" prefix="$" min={0} value={goal.startingBalance} onChange={(n) => set('startingBalance', n)} />
        </div>

        <RangeField label="Time to goal" min={1} max={50} value={Math.round(goal.years)} format={(n) => `${n} ${n === 1 ? 'year' : 'years'}`} onChange={(n) => set('years', n)} />
        <RangeField
          label="Monthly contribution"
          min={0}
          max={Math.max(3000, Math.ceil((result.requiredMonthly * 1.5) / 100) * 100, Math.ceil(goal.monthlyContribution / 100) * 100)}
          step={25}
          value={goal.monthlyContribution}
          format={currency}
          onChange={(n) => set('monthlyContribution', n)}
        />

        {!compact && (
          <fieldset className="space-y-4 border-t border-line pt-5">
            <legend className="sr-only">Assumptions</legend>
            <p className="text-sm font-medium">Assumptions</p>
            <div className="grid gap-4 sm:grid-cols-2">
              <NumberField
                label="Expected annual return"
                suffix="%"
                min={0}
                max={20}
                value={goal.annualReturnPct}
                onChange={(n) => set('annualReturnPct', n)}
                hint="Before fees and taxes."
              />
              <NumberField
                label="Inflation"
                suffix="%"
                min={0}
                max={15}
                value={goal.inflationPct}
                onChange={(n) => set('inflationPct', n)}
                hint="Long-run assumption."
              />
            </div>
            <div className="space-y-1.5">
              <p className="text-sm text-muted">The target amount is in</p>
              <Segmented
                label="Target dollars"
                value={goal.todaysDollars ? 'today' : 'future'}
                options={[
                  { value: 'today', label: 'Today’s dollars' },
                  { value: 'future', label: 'Future dollars' },
                ]}
                onChange={(v) => set('todaysDollars', v === 'today')}
              />
            </div>
          </fieldset>
        )}
      </div>

      {/* Results */}
      <div className="min-w-0">
        <p className="text-sm text-muted">
          To reach {currency(goal.targetAmount)}
          {goal.todaysDollars ? ' (today’s dollars)' : ''} in {yearsLabel} {years === 1 ? 'year' : 'years'}, set aside
        </p>
        <p className="num mt-1 text-5xl font-semibold tracking-display sm:text-6xl">
          {currency(result.requiredMonthly)}
          <span className="ml-1.5 text-lg font-normal tracking-normal text-muted">/ month</span>
        </p>

        <p
          className={`mt-4 inline-block rounded-md px-3 py-1.5 text-sm ${
            result.onPace ? 'bg-accent-soft text-accent' : 'bg-warn-soft text-warn'
          }`}
          role="status"
        >
          {result.onPace
            ? `You are on pace. ${currency(goal.monthlyContribution)} a month reaches ${currency(result.projectedBalance)}.`
            : `${currency(goal.monthlyContribution)} a month falls ${currency(result.shortfall)} short. Add about ${currency(gap)} a month to close it.`}
        </p>

        <div className="mt-6">
          <TrajectoryChart points={result.trajectory} target={result.nominalTarget} summary={summary} height={compact ? 220 : 280} />
        </div>

        <dl className={`mt-6 grid gap-x-8 gap-y-4 border-t border-line pt-5 ${compact ? 'grid-cols-2' : 'grid-cols-2 sm:grid-cols-4'}`}>
          <Stat label="Projected balance" value={currency(result.projectedBalance)} note={goal.todaysDollars ? `${currency(projectedToday)} in today’s dollars` : undefined} />
          <Stat label="You contribute" value={currency(result.totalContributed)} />
          <Stat label="Market growth" value={currency(result.growth)} />
          <Stat
            label="Time to goal at this pace"
            value={result.monthsToTarget === null ? 'Over 100 years' : duration(result.monthsToTarget)}
          />
        </dl>

        {compact ? (
          <p className="mt-5 text-sm">
            <Link to="/tools/goal-pace" className="font-medium text-accent underline underline-offset-4 hover:text-ink">
              Adjust return, inflation and more in the full estimator
            </Link>
          </p>
        ) : (
          <div className="mt-6 space-y-3">
            <Disclaimer>
              Assumptions: a constant {goal.annualReturnPct}% yearly return compounded monthly, deposits at the end of each month,{' '}
              {goal.inflationPct}% yearly inflation, and no taxes or fees. Real returns are uneven and can be negative for years. Treat
              results as a planning estimate, not a forecast.
            </Disclaimer>
          </div>
        )}
        {goal.todaysDollars && !compact && (
          <p className="mt-3 text-xs leading-relaxed text-muted">
            Your {currency(goal.targetAmount)} target is grown by inflation to {currency(result.nominalTarget)} at the goal date, so the amount you save keeps the same buying power.
          </p>
        )}
      </div>
    </div>
  );
}

function Stat({ label, value, note }: { label: string; value: string; note?: string }) {
  return (
    <div>
      <dt className="text-xs text-muted">{label}</dt>
      <dd className="num mt-1 text-lg font-medium">{value}</dd>
      {note && <p className="num mt-0.5 text-xs text-muted">{note}</p>}
    </div>
  );
}
