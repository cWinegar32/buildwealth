import { currency } from '@/utils/format';

export interface Segment {
  label: string;
  value: number;
}

/** Proportional horizontal bar with a legend. Colors come from --seg-N tokens. */
export function SegmentedBar({ segments, label }: { segments: Segment[]; label: string }) {
  const total = segments.reduce((s, x) => s + x.value, 0);
  if (total <= 0) {
    return <p className="rounded-lg border border-dashed border-line px-4 py-6 text-center text-sm text-muted">Add an amount to see the split.</p>;
  }
  return (
    <div>
      <div role="img" aria-label={label} className="flex h-3 w-full overflow-hidden rounded-full bg-line">
        {segments.map((s, i) => (
          <div key={s.label} style={{ width: `${(s.value / total) * 100}%`, backgroundColor: `rgb(var(--seg-${(i % 5) + 1}))` }} />
        ))}
      </div>
      <ul className="mt-3 grid gap-x-6 gap-y-1.5 text-sm sm:grid-cols-2">
        {segments.map((s, i) => (
          <li key={s.label} className="flex items-center justify-between gap-3">
            <span className="flex items-center gap-2 text-muted">
              <span className="h-2.5 w-2.5 rounded-sm" style={{ backgroundColor: `rgb(var(--seg-${(i % 5) + 1}))` }} />
              {s.label}
            </span>
            <span className="num">
              {currency(s.value)} <span className="text-muted">· {Math.round((s.value / total) * 100)}%</span>
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
}
