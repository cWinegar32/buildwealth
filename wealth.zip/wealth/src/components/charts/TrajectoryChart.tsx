import { useState } from 'react';
import type { PointerEvent } from 'react';
import { useElementWidth } from '@/hooks/useElementWidth';
import type { TrajectoryPoint } from '@/types';
import { currency, currencyCompact } from '@/utils/format';

interface Props {
  points: TrajectoryPoint[];
  target: number;
  height?: number;
  summary: string;
}

const PAD = { top: 12, right: 12, bottom: 28, left: 52 };

function niceCeil(v: number): number {
  if (v <= 0) return 1;
  const exp = Math.pow(10, Math.floor(Math.log10(v)));
  const f = v / exp;
  const nf = f <= 1 ? 1 : f <= 2 ? 2 : f <= 2.5 ? 2.5 : f <= 5 ? 5 : 10;
  return nf * exp;
}

function pickYearStep(totalYears: number): number {
  const options = [1, 2, 5, 10, 20, 25];
  return options.find((s) => totalYears / s <= 6) ?? 25;
}

export function TrajectoryChart({ points, target, height = 260, summary }: Props) {
  const [ref, width] = useElementWidth<HTMLDivElement>();
  const [hover, setHover] = useState<number | null>(null);

  const last = points[points.length - 1];
  const totalMonths = Math.max(1, last.month);
  const maxValue = Math.max(target, last.balance, last.contributed);
  const yMax = niceCeil(maxValue * 1.05);
  const innerW = Math.max(10, width - PAD.left - PAD.right);
  const innerH = height - PAD.top - PAD.bottom;

  const x = (month: number) => PAD.left + (month / totalMonths) * innerW;
  const y = (v: number) => PAD.top + innerH - (v / yMax) * innerH;

  const line = (key: 'balance' | 'contributed') =>
    points.map((p, i) => `${i === 0 ? 'M' : 'L'}${x(p.month).toFixed(1)} ${y(p[key]).toFixed(1)}`).join(' ');
  const area = `${line('balance')} L${x(last.month).toFixed(1)} ${y(0)} L${x(0)} ${y(0)} Z`;

  const yTicks = [0, 1, 2, 3, 4].map((i) => (yMax * i) / 4);
  const totalYears = totalMonths / 12;
  const step = pickYearStep(totalYears);
  const xTicks: number[] = [];
  for (let yr = 0; yr <= totalYears; yr += step) xTicks.push(yr);

  const onMove = (e: PointerEvent<SVGSVGElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const month = ((e.clientX - rect.left - PAD.left) / innerW) * totalMonths;
    let best = 0;
    for (let i = 1; i < points.length; i++) {
      if (Math.abs(points[i].month - month) < Math.abs(points[best].month - month)) best = i;
    }
    setHover(best);
  };

  const hp = hover !== null ? points[hover] : null;
  const tooltipLeft = hp ? Math.min(Math.max(x(hp.month) - 80, 0), Math.max(0, width - 168)) : 0;

  return (
    <div>
      <div ref={ref} className="relative w-full" style={{ height }}>
        {width > 0 && (
          <svg
            width={width}
            height={height}
            role="img"
            aria-label={summary}
            className="touch-pan-y select-none"
            onPointerMove={onMove}
            onPointerLeave={() => setHover(null)}
          >
            {yTicks.map((t) => (
              <g key={t}>
                <line x1={PAD.left} x2={width - PAD.right} y1={y(t)} y2={y(t)} className="stroke-line" strokeWidth={1} />
                <text x={PAD.left - 8} y={y(t) + 4} textAnchor="end" className="fill-muted num" fontSize={11}>
                  {currencyCompact(t)}
                </text>
              </g>
            ))}
            {xTicks.map((t) => (
              <text key={t} x={x(t * 12)} y={height - 8} textAnchor={t === 0 ? 'start' : 'middle'} className="fill-muted num" fontSize={11}>
                {t === 0 ? 'Now' : `${t}y`}
              </text>
            ))}

            <path d={area} className="fill-accent-soft" />
            <path d={line('contributed')} fill="none" className="stroke-muted/60" strokeWidth={1.5} strokeDasharray="2 4" />
            <path d={line('balance')} fill="none" className="stroke-accent" strokeWidth={2.25} strokeLinejoin="round" />

            <line x1={PAD.left} x2={width - PAD.right} y1={y(target)} y2={y(target)} className="stroke-ink" strokeWidth={1.25} strokeDasharray="5 4" />
            <text x={width - PAD.right} y={y(target) - 6} textAnchor="end" className="fill-ink num" fontSize={11} fontWeight={500}>
              Goal {currencyCompact(target)}
            </text>

            {hp && (
              <g>
                <line x1={x(hp.month)} x2={x(hp.month)} y1={PAD.top} y2={y(0)} className="stroke-ink/20" />
                <circle cx={x(hp.month)} cy={y(hp.balance)} r={4.5} className="fill-accent stroke-surface" strokeWidth={2} />
              </g>
            )}
          </svg>
        )}
        {hp && (
          <div
            className="pointer-events-none absolute top-1 rounded-lg border border-line bg-surface px-3 py-2 text-xs shadow-sm"
            style={{ left: tooltipLeft, width: 160 }}
          >
            <p className="font-medium">{hp.year === 0 ? 'Today' : `After ${Number.isInteger(hp.year) ? hp.year : hp.year.toFixed(1)} years`}</p>
            <p className="num mt-1 text-muted">
              Balance <span className="text-ink">{currency(hp.balance)}</span>
            </p>
            <p className="num text-muted">
              Contributed <span className="text-ink">{currency(hp.contributed)}</span>
            </p>
          </div>
        )}
      </div>
      <ul className="mt-3 flex flex-wrap gap-x-5 gap-y-1 text-xs text-muted">
        <li className="flex items-center gap-2"><span className="h-0.5 w-4 bg-accent" />Projected balance</li>
        <li className="flex items-center gap-2"><span className="h-0 w-4 border-t border-dotted border-muted" />What you put in</li>
        <li className="flex items-center gap-2"><span className="h-0 w-4 border-t border-dashed border-ink" />Goal</li>
      </ul>
    </div>
  );
}
