import { Link } from 'react-router-dom';
import { BRAND, DISCLAIMER } from '@/data/content';

export function Footer() {
  return (
    <footer className="border-t border-line">
      <div className="mx-auto grid max-w-page gap-8 px-5 py-12 sm:px-8 md:grid-cols-[1fr_auto]">
        <div>
          <p className="font-semibold">{BRAND.name}</p>
          <p className="mt-1 text-sm text-muted">{BRAND.tagline}</p>
          <p className="mt-5 max-w-xl text-xs leading-relaxed text-muted">{DISCLAIMER}</p>
        </div>
        <nav aria-label="Footer" className="flex flex-wrap gap-x-6 gap-y-2 self-start text-sm text-muted">
          <Link to="/tools" className="hover:text-ink">Tools</Link>
          <Link to="/philosophy" className="hover:text-ink">Philosophy</Link>
          <Link to="/get-started" className="hover:text-ink">Quick start</Link>
        </nav>
      </div>
    </footer>
  );
}
