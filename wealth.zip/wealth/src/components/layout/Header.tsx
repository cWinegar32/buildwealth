import { useEffect, useState } from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';
import { BRAND } from '@/data/content';
import { LinkButton } from '@/components/ui/Button';
import { Logo } from './Logo';

const NAV = [
  { to: '/', label: 'Overview', end: true },
  { to: '/tools', label: 'Tools', end: false },
  { to: '/philosophy', label: 'Philosophy', end: false },
  { to: '/get-started', label: 'Quick start', end: false },
];

const linkClass = ({ isActive }: { isActive: boolean }) =>
  `rounded-md px-3 py-1.5 text-sm transition-colors ${isActive ? 'bg-ink/5 font-medium text-ink' : 'text-muted hover:text-ink'}`;

export function Header() {
  const [open, setOpen] = useState(false);
  const { pathname } = useLocation();

  useEffect(() => setOpen(false), [pathname]);

  return (
    <header className="sticky top-0 z-30 border-b border-line bg-bg/90 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-page items-center justify-between gap-4 px-5 sm:px-8">
        <Link to="/" className="flex items-center gap-2.5 text-[17px] font-semibold tracking-tight">
          <Logo />
          {BRAND.name}
        </Link>

        <nav aria-label="Primary" className="hidden items-center gap-1 md:flex">
          {NAV.map((n) => (
            <NavLink key={n.to} to={n.to} end={n.end} className={linkClass}>
              {n.label}
            </NavLink>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <LinkButton to="/tools/goal-pace" className="hidden md:inline-flex">
            Estimate a goal
          </LinkButton>
          <button
            type="button"
            className="inline-flex h-9 items-center rounded-lg border border-line bg-surface px-3 text-sm md:hidden"
            aria-expanded={open}
            aria-controls="mobile-menu"
            onClick={() => setOpen((o) => !o)}
          >
            {open ? 'Close' : 'Menu'}
          </button>
        </div>
      </div>

      {open && (
        <nav id="mobile-menu" aria-label="Primary" className="border-t border-line bg-bg px-5 pb-5 pt-3 md:hidden">
          <ul className="flex flex-col gap-1">
            {NAV.map((n) => (
              <li key={n.to}>
                <NavLink to={n.to} end={n.end} className={({ isActive }) => `block ${linkClass({ isActive })} py-2.5 text-base`}>
                  {n.label}
                </NavLink>
              </li>
            ))}
          </ul>
          <LinkButton to="/tools/goal-pace" size="lg" className="mt-4 w-full">
            Estimate a goal
          </LinkButton>
        </nav>
      )}
    </header>
  );
}
