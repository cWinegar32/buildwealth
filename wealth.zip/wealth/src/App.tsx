import { Route, Routes } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { GetStarted } from '@/pages/GetStarted';
import { Home } from '@/pages/Home';
import { NotFound } from '@/pages/NotFound';
import { Philosophy } from '@/pages/Philosophy';
import { Tools } from '@/pages/Tools';

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<Home />} />
        <Route path="tools" element={<Tools />} />
        <Route path="tools/:tool" element={<Tools />} />
        <Route path="philosophy" element={<Philosophy />} />
        <Route path="get-started" element={<GetStarted />} />
        <Route path="*" element={<NotFound />} />
      </Route>
    </Routes>
  );
}
