import { LinkButton } from '@/components/ui/Button';
import { Section } from '@/components/ui/PageHeader';

export function NotFound() {
  return (
    <Section className="max-w-3xl">
      <h1 className="text-4xl font-semibold tracking-display">That page does not exist.</h1>
      <p className="mt-4 text-lg text-muted">The link may be old or mistyped. Head back to the overview or open a tool.</p>
      <div className="mt-8 flex gap-3">
        <LinkButton to="/" size="lg">Back to overview</LinkButton>
        <LinkButton to="/tools" variant="secondary" size="lg">Open tools</LinkButton>
      </div>
    </Section>
  );
}
