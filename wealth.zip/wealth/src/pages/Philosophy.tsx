import { PageHeader, Section } from '@/components/ui/PageHeader';
import { LADDER, PRINCIPLES, ROADMAP } from '@/data/content';
import type { RoadmapStatus } from '@/types';

const GROUPS: { status: RoadmapStatus; title: string; blurb: string }[] = [
  { status: 'live', title: 'Available now', blurb: 'Working in this version.' },
  { status: 'next', title: 'Next', blurb: 'In design or early build.' },
  { status: 'later', title: 'Later', blurb: 'Under consideration. No dates promised.' },
];

export function Philosophy() {
  return (
    <>
      <PageHeader
        title="From paycheck to compounding."
        intro="Most money advice assumes steady income and spare cash. This platform starts where you are, including seasonal or variable pay, and builds toward growth that works without you."
      />

      <Section>
        <div className="grid gap-10 lg:grid-cols-[4fr_8fr] lg:gap-14">
          <div>
            <h2 className="text-2xl font-semibold tracking-display sm:text-3xl">A path in five steps</h2>
            <p className="mt-3 text-muted">The order matters. Each step makes the next one safer.</p>
          </div>
          <ol className="border-t border-line">
            {LADDER.map((s, i) => (
              <li key={s.title} className="grid grid-cols-[2.5rem_1fr] gap-x-2 border-b border-line py-6">
                <span className="num pt-0.5 text-sm text-muted" aria-hidden="true">{i + 1}</span>
                <div>
                  <h3 className="text-lg font-semibold">{s.title}</h3>
                  <p className="mt-1.5 leading-relaxed text-muted">{s.body}</p>
                </div>
              </li>
            ))}
          </ol>
        </div>
      </Section>

      <div className="border-y border-line bg-surface">
        <Section>
          <h2 className="text-2xl font-semibold tracking-display sm:text-3xl">How we work</h2>
          <dl className="mt-8 grid gap-x-10 gap-y-8 sm:grid-cols-2">
            {PRINCIPLES.map((p) => (
              <div key={p.title}>
                <dt className="font-semibold">{p.title}</dt>
                <dd className="mt-1.5 leading-relaxed text-muted">{p.body}</dd>
              </div>
            ))}
          </dl>
        </Section>
      </div>

      <Section>
        <h2 className="text-2xl font-semibold tracking-display sm:text-3xl">Roadmap</h2>
        <div className="mt-8 grid gap-10 md:grid-cols-3">
          {GROUPS.map((g) => (
            <div key={g.status}>
              <h3 className="font-semibold">{g.title}</h3>
              <p className="mt-0.5 text-sm text-muted">{g.blurb}</p>
              <ul className="mt-4 border-t border-line">
                {ROADMAP.filter((r) => r.status === g.status).map((r) => (
                  <li key={r.title} className="border-b border-line py-3.5">
                    <p className="font-medium">{r.title}</p>
                    <p className="mt-0.5 text-sm leading-relaxed text-muted">{r.description}</p>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </Section>
    </>
  );
}
