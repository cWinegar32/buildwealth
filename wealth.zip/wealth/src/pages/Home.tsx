import { Link } from 'react-router-dom';
import { GoalPaceCalculator } from '@/components/tools/GoalPaceCalculator';
import { LinkButton } from '@/components/ui/Button';
import { Section } from '@/components/ui/PageHeader';
import { PILLARS } from '@/data/content';

export function Home() {
  return (
    <>
      <div className="border-b border-line">
        <div className="mx-auto grid max-w-page gap-12 px-5 pb-14 pt-12 sm:px-8 sm:pt-16 lg:grid-cols-[minmax(0,5fr)_minmax(0,7fr)] lg:gap-14 lg:pb-20 lg:pt-20">
          <div className="lg:pt-4">
            <h1 className="text-4xl font-semibold leading-[1.06] tracking-display sm:text-5xl lg:text-[3.5rem]">
              Know when your savings will get you there.
            </h1>
            <p className="mt-6 max-w-md text-lg leading-relaxed text-muted">
              Calm, plain-English tools for young adults turning a first paycheck, or an uneven one, into long-term financial independence.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <LinkButton to="/get-started" size="lg">
                Set up a goal
              </LinkButton>
              <LinkButton to="/tools" variant="secondary" size="lg">
                Browse the tools
              </LinkButton>
            </div>
            <p className="mt-6 text-sm text-muted">Free. No account. Your numbers stay in your browser.</p>
          </div>
          <div className="min-w-0 rounded-2xl border border-line bg-surface p-5 sm:p-7">
            <GoalPaceCalculator variant="compact" />
          </div>
        </div>
      </div>

      <Section>
        <h2 className="max-w-xl text-3xl font-semibold tracking-display sm:text-4xl">Four tools, one job: a plan you can follow.</h2>
        <div className="mt-10 grid border-t border-line sm:grid-cols-2 lg:grid-cols-4">
          {PILLARS.map((p, i) => (
            <div
              key={p.title}
              className={`border-b border-line py-7 sm:px-6 lg:border-b-0 ${i % 2 === 1 ? 'sm:border-l' : ''} ${i > 0 ? 'lg:border-l' : ''} ${i === 0 ? 'lg:pl-0' : ''} ${i === 2 ? 'sm:border-l-0 lg:border-l' : ''}`}
            >
              <h3 className="text-lg font-semibold">{p.title}</h3>
              <p className="mt-2 text-[15px] leading-relaxed text-muted">{p.body}</p>
              <Link to={p.to} className="mt-4 inline-block text-sm font-medium text-accent underline underline-offset-4 hover:text-ink">
                {p.cta}
              </Link>
            </div>
          ))}
        </div>
      </Section>

      <div className="border-t border-line bg-surface">
        <Section className="grid gap-10 lg:grid-cols-[5fr_7fr] lg:gap-14">
          <h2 className="text-3xl font-semibold tracking-display sm:text-4xl">The math is simple, and we show it.</h2>
          <div className="space-y-5 text-[17px] leading-relaxed text-muted">
            <p>
              Each estimate uses a steady yearly return, compounded monthly, with deposits at month-end. You can change the return and inflation assumptions, and see your goal in today’s dollars or future dollars.
            </p>
            <p>
              Markets do not move in straight lines. Treat every result as a way to compare plans, not as a prediction. Nothing here is financial advice.
            </p>
            <p>
              <Link to="/philosophy" className="font-medium text-accent underline underline-offset-4 hover:text-ink">
                Read how we think about getting from paycheck to compounding
              </Link>
            </p>
          </div>
        </Section>
      </div>
    </>
  );
}
