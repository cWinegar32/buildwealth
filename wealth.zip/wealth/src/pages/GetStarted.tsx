import { useState } from 'react';
import type { FormEvent } from 'react';
import { GOAL_PRESETS, defaultGoal } from '@/data/goals';
import { Button, LinkButton } from '@/components/ui/Button';
import { NumberField } from '@/components/ui/Field';
import { PageHeader, Section } from '@/components/ui/PageHeader';
import { useGoalInputs } from '@/hooks/useGoalInputs';
import { useLocalStorage } from '@/hooks/useLocalStorage';
import type { GoalInputs } from '@/types';
import { evaluateGoal } from '@/utils/finance';
import { currency } from '@/utils/format';

const STEPS = ['Goal', 'Numbers', 'Your pace'];
const ENDPOINT = import.meta.env.VITE_WAITLIST_ENDPOINT;

export function GetStarted() {
  const [goal, setGoal] = useGoalInputs();
  const [step, setStep] = useState(0);
  const set = <K extends keyof GoalInputs>(key: K, value: GoalInputs[K]) => setGoal((g) => ({ ...g, [key]: value }));
  const result = evaluateGoal(goal);

  return (
    <>
      <PageHeader
        title="Start with one goal."
        intro="Three quick steps. No account needed, and your answers are saved in this browser so you can pick up in the tools."
      />
      <Section className="max-w-3xl">
        <ol className="mb-10 flex gap-6 border-b border-line text-sm" aria-label="Progress">
          {STEPS.map((s, i) => (
            <li
              key={s}
              aria-current={i === step ? 'step' : undefined}
              className={`-mb-px border-b-2 pb-3 ${i === step ? 'border-accent font-medium text-ink' : 'border-transparent text-muted'}`}
            >
              <span className="num mr-2">{i + 1}</span>
              {s}
            </li>
          ))}
        </ol>

        {step === 0 && (
          <div>
            <h2 className="text-2xl font-semibold tracking-display">What are you saving for?</h2>
            <div role="radiogroup" aria-label="Goal type" className="mt-6 grid gap-3 sm:grid-cols-2">
              {GOAL_PRESETS.map((p) => {
                const selected = goal.presetId === p.id;
                return (
                  <button
                    key={p.id}
                    type="button"
                    role="radio"
                    aria-checked={selected}
                    onClick={() => setGoal(defaultGoal(p.id))}
                    className={`rounded-xl border p-4 text-left transition-colors ${selected ? 'border-accent bg-accent-soft' : 'border-line bg-surface hover:border-ink/30'}`}
                  >
                    <span className="block font-medium">{p.label}</span>
                    <span className="mt-1 block text-sm text-muted">{p.description}</span>
                  </button>
                );
              })}
            </div>
            <Button size="lg" className="mt-8" onClick={() => setStep(1)}>
              Continue
            </Button>
          </div>
        )}

        {step === 1 && (
          <div>
            <h2 className="text-2xl font-semibold tracking-display">Tell us the numbers.</h2>
            <p className="mt-2 text-muted">Rough is fine. You can change anything later.</p>
            <div className="mt-6 grid gap-5 sm:grid-cols-2">
              <NumberField label="Target amount (today’s dollars)" prefix="$" min={0} value={goal.targetAmount} onChange={(n) => set('targetAmount', n)} />
              <NumberField label="Years to reach it" suffix="yrs" min={1} max={60} value={goal.years} onChange={(n) => set('years', Math.max(1, Math.round(n)))} />
              <NumberField label="Saved so far" prefix="$" min={0} value={goal.startingBalance} onChange={(n) => set('startingBalance', n)} />
              <NumberField label="You can save each month" prefix="$" min={0} value={goal.monthlyContribution} onChange={(n) => set('monthlyContribution', n)} />
            </div>
            <div className="mt-8 flex gap-3">
              <Button variant="secondary" size="lg" onClick={() => setStep(0)}>
                Back
              </Button>
              <Button size="lg" onClick={() => setStep(2)}>
                See my pace
              </Button>
            </div>
          </div>
        )}

        {step === 2 && (
          <div>
            <h2 className="text-2xl font-semibold tracking-display">Your pace</h2>
            <p className="num mt-4 text-5xl font-semibold tracking-display">
              {currency(result.requiredMonthly)}
              <span className="ml-1.5 text-lg font-normal tracking-normal text-muted">/ month</span>
            </p>
            <p className="mt-3 max-w-xl leading-relaxed text-muted">
              That is what it takes to reach {currency(goal.targetAmount)} in today’s dollars within {goal.years} {goal.years === 1 ? 'year' : 'years'}, assuming {goal.annualReturnPct}% yearly growth and {goal.inflationPct}% inflation.{' '}
              {result.onPace
                ? `At ${currency(goal.monthlyContribution)} a month, you are on pace.`
                : `At ${currency(goal.monthlyContribution)} a month, you would be about ${currency(result.shortfall)} short.`}
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <LinkButton to="/tools/goal-pace" size="lg">
                Open the full estimator
              </LinkButton>
              <Button variant="secondary" size="lg" onClick={() => setStep(1)}>
                Edit numbers
              </Button>
            </div>
            <Waitlist presetId={goal.presetId} />
          </div>
        )}
      </Section>
    </>
  );
}

type Status = 'idle' | 'sending' | 'done' | 'error';

function Waitlist({ presetId }: { presetId: string }) {
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState<Status>('idle');
  const [, setSaved] = useLocalStorage<string[]>('wealth.waitlist.v1', []);
  const valid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!valid) return;
    setStatus('sending');
    try {
      if (ENDPOINT) {
        const res = await fetch(ENDPOINT, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
          body: JSON.stringify({ email, goal: presetId }),
        });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
      } else {
        setSaved((list) => [...list, email]);
      }
      setStatus('done');
    } catch {
      setStatus('error');
    }
  };

  return (
    <div className="mt-14 border-t border-line pt-8">
      <h3 className="text-lg font-semibold">Hear about new tools</h3>
      <p className="mt-1 max-w-lg text-sm text-muted">One short email when the monthly tracker and net-worth history launch. No spam, and no account.</p>
      {status === 'done' ? (
        <p role="status" className="mt-4 rounded-lg bg-accent-soft px-4 py-3 text-sm text-accent">
          {ENDPOINT ? 'Thanks. You are on the list.' : 'Saved on this device. Email collection is not connected yet in this build.'}
        </p>
      ) : (
        <form onSubmit={submit} className="mt-4 flex max-w-lg flex-col gap-3 sm:flex-row" noValidate>
          <div className="flex-1">
            <label htmlFor="waitlist-email" className="sr-only">
              Email address
            </label>
            <input
              id="waitlist-email"
              type="email"
              autoComplete="email"
              className="input h-11"
              placeholder="you@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>
          <button type="submit" disabled={!valid || status === 'sending'} className="inline-flex h-11 items-center justify-center rounded-lg bg-ink px-5 text-[15px] font-medium text-white transition-colors hover:bg-ink/90 disabled:cursor-not-allowed disabled:opacity-50">
            {status === 'sending' ? 'Sending…' : 'Join the waitlist'}
          </button>
        </form>
      )}
      {status === 'error' && (
        <p role="alert" className="mt-3 text-sm text-warn">
          That did not go through. Check your connection and try again.
        </p>
      )}
    </div>
  );
}
