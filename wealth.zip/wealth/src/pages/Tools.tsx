import { Link, NavLink, useParams } from 'react-router-dom';
import { BudgetPlanner } from '@/components/tools/BudgetPlanner';
import { GoalPaceCalculator } from '@/components/tools/GoalPaceCalculator';
import { InvestingEducation } from '@/components/tools/InvestingEducation';
import { WealthTracker } from '@/components/tools/WealthTracker';
import { PageHeader, Section } from '@/components/ui/PageHeader';
import { TOOLS, getTool } from '@/data/tools';
import { NotFound } from './NotFound';

const MODULES: Record<string, () => JSX.Element> = {
  'goal-pace': () => <GoalPaceCalculator />,
  budgeting: () => <BudgetPlanner />,
  'wealth-tracker': () => <WealthTracker />,
  investing: () => <InvestingEducation />,
};

export function Tools() {
  const { tool } = useParams();

  if (!tool) {
    return (
      <>
        <PageHeader
          title="Tools"
          intro="Four small tools that work on their own and share your numbers. Each one opens with working basics today and has a clear next step."
        />
        <Section>
          <div className="grid border-t border-line md:grid-cols-2">
            {TOOLS.map((t, i) => (
              <article key={t.slug} className={`border-b border-line py-8 md:px-8 ${i % 2 === 0 ? 'md:border-r md:pl-0' : 'md:pr-0'}`}>
                <h2 className="text-xl font-semibold">{t.title}</h2>
                <p className="mt-1 text-muted">{t.scope}</p>
                <dl className="mt-5 space-y-3 text-sm">
                  <div>
                    <dt className="font-medium">Live now</dt>
                    <dd className="mt-0.5 leading-relaxed text-muted">{t.live}</dd>
                  </div>
                  <div>
                    <dt className="font-medium">Up next</dt>
                    <dd className="mt-0.5 leading-relaxed text-muted">{t.next}</dd>
                  </div>
                </dl>
                <Link to={`/tools/${t.slug}`} className="mt-5 inline-block text-sm font-medium text-accent underline underline-offset-4 hover:text-ink">
                  Open {t.title}
                </Link>
              </article>
            ))}
          </div>
        </Section>
      </>
    );
  }

  const meta = getTool(tool);
  const Module = MODULES[tool];
  if (!meta || !Module) return <NotFound />;

  return (
    <>
      <PageHeader title={meta.title} intro={meta.tagline} />
      <div className="border-b border-line">
        <nav aria-label="Tools" className="mx-auto max-w-page overflow-x-auto px-5 sm:px-8">
          <ul className="flex min-w-max gap-6">
            <li>
              <NavLink to="/tools" end className="block border-b-2 border-transparent py-3 text-sm text-muted hover:text-ink">
                All tools
              </NavLink>
            </li>
            {TOOLS.map((t) => (
              <li key={t.slug}>
                <NavLink
                  to={`/tools/${t.slug}`}
                  className={({ isActive }) =>
                    `block border-b-2 py-3 text-sm ${isActive ? 'border-accent font-medium text-ink' : 'border-transparent text-muted hover:text-ink'}`
                  }
                >
                  {t.title}
                </NavLink>
              </li>
            ))}
          </ul>
        </nav>
      </div>
      <Section>
        <Module />
        <p className="mt-14 max-w-2xl border-t border-line pt-5 text-sm text-muted">
          <span className="font-medium text-ink">Up next:</span> {meta.next}
        </p>
      </Section>
    </>
  );
}
