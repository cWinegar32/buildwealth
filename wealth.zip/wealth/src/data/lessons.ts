import type { Lesson } from '@/types';

/** Add a lesson by appending an object here. The Investing Education module renders whatever is in this list. */
export const LESSONS: Lesson[] = [
  {
    id: 'compounding',
    title: 'Compounding: growth on top of growth',
    summary: 'Why starting early matters more than starting big.',
    minutes: 4,
    illustration: 'compounding',
    sections: [
      {
        heading: 'The idea',
        body: [
          'When an investment earns a return, that return is added to your balance. Next period, you earn on the original money and on the earlier gains. Over short periods the effect is small. Over decades it becomes the biggest part of the result.',
          'A rough shortcut is the rule of 72: divide 72 by an annual return to estimate how many years it takes to double. At 6%, about 12 years. At 8%, about 9.',
        ],
      },
      {
        heading: 'Why time beats size',
        body: [
          'Money invested in your early twenties has the longest runway. A modest monthly amount started at 22 can end up close to a larger amount started at 32, because the early dollars get extra years of growth.',
          'This is an estimate, not a promise. Real returns vary a lot from year to year, and some years are negative. The illustration below uses a steady rate so the shape of the curve is easy to see.',
        ],
      },
    ],
    takeaways: [
      'Start with whatever amount is realistic. Raise it when your income rises.',
      'Staying invested through bad years matters as much as picking where to invest.',
      'Fees and taxes reduce the rate you actually keep.',
    ],
  },
  {
    id: 'index-funds',
    title: 'Index funds: owning the market, cheaply',
    summary: 'What they are, and why many people start here.',
    minutes: 5,
    sections: [
      {
        heading: 'What an index fund is',
        body: [
          'A stock index is a list of companies, such as the largest 500 in the US or most of the listed companies in a country. An index fund buys all of them, in proportion, so you own a small slice of each with one purchase.',
          'Because the fund simply follows the list, nobody is paid to pick winners. That keeps costs low.',
        ],
      },
      {
        heading: 'Why cost matters',
        body: [
          'A fund’s yearly fee is called the expense ratio. A difference of one percentage point sounds small, but it comes out of your return every year, and it compounds too. Over thirty years it can take a large share of your final balance.',
          'Many broad index funds charge a small fraction of a percent. Compare the expense ratio before you buy, along with what the fund actually holds.',
        ],
      },
      {
        heading: 'What it does not do',
        body: [
          'An index fund spreads risk across many companies, but it still falls when the market falls. Diversification reduces the harm from any one company failing. It does not remove market risk.',
        ],
      },
    ],
    takeaways: [
      'Broad, low-cost funds are a common core for long-term investors.',
      'Check the expense ratio and what the fund holds.',
      'Diversified is not the same as safe.',
    ],
  },
  {
    id: 'risk-horizon',
    title: 'Risk and time horizon',
    summary: 'Match the money to when you will need it.',
    minutes: 5,
    sections: [
      {
        heading: 'Two kinds of risk',
        body: [
          'Market risk is the chance your investments fall in value, sometimes sharply and for years. Shortfall risk is the chance you do not save enough, or your money does not keep up with prices. Avoiding the first can create the second.',
        ],
      },
      {
        heading: 'Use the time horizon',
        body: [
          'Money you need within a few years, such as a down payment or an emergency fund, does not have time to recover from a market drop. It belongs in low-risk places like a savings account.',
          'Money you will not touch for decades can usually take more swings, because there is time to recover. That is why the presets in the Goal Pace Estimator use different expected returns for different goals.',
        ],
      },
      {
        heading: 'Behavior is the hidden risk',
        body: [
          'Selling during a downturn locks in the loss. Before you invest, decide how much of a drop you could watch without changing the plan. If a 30% fall would make you sell, hold less in stocks.',
        ],
      },
    ],
    takeaways: [
      'Short-term goals: prioritize stability.',
      'Long-term goals: accept volatility in exchange for growth.',
      'Build an emergency fund first so you are never forced to sell at a bad time.',
    ],
  },
  {
    id: 'tax-advantaged',
    title: 'Tax-advantaged accounts',
    summary: 'Keep more of what your money earns. US-focused.',
    minutes: 6,
    sections: [
      {
        heading: 'Why the account matters',
        body: [
          'The same investment can leave you with different amounts depending on the account that holds it. Tax-advantaged accounts reduce or delay taxes, in exchange for rules about when you can withdraw.',
          'The rules below describe the US. Contribution limits, income limits and rules change, so check IRS.gov for the current year before you act.',
        ],
      },
      {
        heading: 'The main ones',
        body: [
          '401(k) or similar workplace plan: contributions come from your paycheck. Many employers add a match, which is extra pay you only receive if you contribute. A traditional 401(k) generally lowers taxable income now; a Roth option is taxed now and can be tax-free later.',
          'IRA (traditional or Roth): an individual retirement account you open yourself. Roth contributions use after-tax money and qualified withdrawals can be tax-free. Eligibility for a Roth depends on income.',
          'HSA: if you have an eligible high-deductible health plan, contributions can be tax-free going in, growing, and coming out for medical costs.',
        ],
      },
      {
        heading: 'A common order of operations',
        body: [
          'Many people work through this in order: build a small starter emergency fund, contribute enough to get your full employer match, pay off high-interest debt, then fund a Roth IRA or HSA if eligible, then increase workplace contributions. It is a starting point, not a rule, and your situation may differ.',
        ],
      },
    ],
    takeaways: [
      'An employer match is part of your compensation. Claim it.',
      'Retirement accounts have withdrawal rules. Do not put emergency money in them.',
      'Limits change every year. Always check the current figures.',
    ],
  },
];
