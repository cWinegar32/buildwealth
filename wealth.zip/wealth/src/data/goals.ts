import type { GoalInputs, GoalPresetId } from '@/types';

export interface GoalPreset {
  id: GoalPresetId;
  label: string;
  description: string;
  defaults: Omit<GoalInputs, 'presetId'>;
}

/**
 * Starter assumptions only. Shorter goals use lower expected returns because money needed
 * soon should not depend on stock-market gains.
 */
export const GOAL_PRESETS: GoalPreset[] = [
  {
    id: 'home',
    label: 'Home down payment',
    description: 'A deposit within the next few years.',
    defaults: { targetAmount: 60000, years: 5, startingBalance: 5000, monthlyContribution: 750, annualReturnPct: 4.5, inflationPct: 2.5, todaysDollars: true },
  },
  {
    id: 'retirement',
    label: 'Retirement',
    description: 'Long-term investing, decades out.',
    defaults: { targetAmount: 1000000, years: 40, startingBalance: 2000, monthlyContribution: 400, annualReturnPct: 7, inflationPct: 2.5, todaysDollars: true },
  },
  {
    id: 'milestone',
    label: 'Lifestyle milestone',
    description: 'A move, a degree, a year off, a business.',
    defaults: { targetAmount: 25000, years: 3, startingBalance: 1000, monthlyContribution: 550, annualReturnPct: 4, inflationPct: 2.5, todaysDollars: true },
  },
  {
    id: 'emergency',
    label: 'Emergency fund',
    description: 'Three to six months of essentials.',
    defaults: { targetAmount: 12000, years: 2, startingBalance: 1500, monthlyContribution: 400, annualReturnPct: 3.5, inflationPct: 2.5, todaysDollars: true },
  },
];

export function getPreset(id: GoalPresetId): GoalPreset {
  return GOAL_PRESETS.find((p) => p.id === id) ?? GOAL_PRESETS[0];
}

export function defaultGoal(id: GoalPresetId = 'home'): GoalInputs {
  return { presetId: id, ...getPreset(id).defaults };
}

export function isGoalInputs(value: unknown): value is GoalInputs {
  if (typeof value !== 'object' || value === null) return false;
  const v = value as Record<string, unknown>;
  return (
    typeof v.presetId === 'string' &&
    GOAL_PRESETS.some((p) => p.id === v.presetId) &&
    ['targetAmount', 'years', 'startingBalance', 'monthlyContribution', 'annualReturnPct', 'inflationPct'].every(
      (k) => typeof v[k] === 'number' && Number.isFinite(v[k] as number),
    ) &&
    typeof v.todaysDollars === 'boolean'
  );
}
