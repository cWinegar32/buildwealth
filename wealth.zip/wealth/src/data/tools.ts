import type { ToolMeta } from '@/types';

export const TOOLS: ToolMeta[] = [
  {
    slug: 'goal-pace',
    title: 'Goal Pace Estimator',
    tagline: 'How much to save, and how long it takes.',
    scope: 'Estimate the monthly savings a goal needs, and how your current pace compares.',
    live: 'Required monthly savings, projected trajectory, inflation toggle, four goal presets.',
    next: 'Saved goals, multiple goals side by side, and a return range instead of a single rate.',
  },
  {
    slug: 'budgeting',
    title: 'Budgeting Help',
    tagline: 'Split a paycheck on purpose.',
    scope: 'Turn monthly take-home pay into needs, wants and savings.',
    live: '50/30/20 starting point, custom split, and a one-click hand-off to the Goal Pace Estimator.',
    next: 'A monthly tracker that compares planned and actual spending, built for uneven income.',
  },
  {
    slug: 'wealth-tracker',
    title: 'Wealth Tracker',
    tagline: 'What you own, what you owe.',
    scope: 'See net worth and where it sits: cash, investments, property and debt.',
    live: 'Editable assets and liabilities, net worth, allocation bar. Saved only in this browser.',
    next: 'Dated snapshots so you can see net worth change over time, plus CSV export.',
  },
  {
    slug: 'investing',
    title: 'Investing Education',
    tagline: 'The basics, in plain English.',
    scope: 'Short lessons on compounding, index funds, risk and tax-advantaged accounts.',
    live: 'Four lessons with a compounding illustration you can adjust.',
    next: 'More lessons, glossary, and quick checks after each lesson.',
  },
];

export function getTool(slug: string | undefined): ToolMeta | undefined {
  return TOOLS.find((t) => t.slug === slug);
}
