import type { RoadmapItem } from '@/types';

export const BRAND = {
  name: 'Wealth',
  tagline: 'Money tools for your first decade',
};

export const PILLARS = [
  { title: 'Budget', body: 'Decide where each paycheck goes before it disappears.', to: '/tools/budgeting', cta: 'Open budgeting' },
  { title: 'Track', body: 'See what you own and owe, and watch net worth move.', to: '/tools/wealth-tracker', cta: 'Open tracker' },
  { title: 'Learn', body: 'Plain-English lessons on investing, without the jargon.', to: '/tools/investing', cta: 'Open lessons' },
  { title: 'Pace', body: 'Find out what a goal needs each month, and whether you are on track.', to: '/tools/goal-pace', cta: 'Open estimator' },
];

export const LADDER = [
  {
    title: 'Make the month predictable',
    body: 'Budget against your lowest recent month, not your best. If income is seasonal or variable, a steady baseline is what turns surprises into plans.',
  },
  {
    title: 'Build a buffer',
    body: 'A starter emergency fund keeps one bad month from becoming debt. It is also what lets you stay invested when markets drop.',
  },
  {
    title: 'Capture free money',
    body: 'If an employer matches retirement contributions, that match is the best guaranteed return available. Take all of it.',
  },
  {
    title: 'Invest steadily',
    body: 'Automatic, regular contributions to diversified, low-cost funds. The habit matters more than the amount at the start.',
  },
  {
    title: 'Raise the rate',
    body: 'With each raise or new income stream, send a share to savings before lifestyle absorbs it. Small increases compound too.',
  },
];

export const PRINCIPLES = [
  { title: 'Assumptions on the surface', body: 'Every calculator shows the rates and rules it uses, and lets you change them.' },
  { title: 'Education, not advice', body: 'We explain how things work. We do not recommend specific products or tell you what to buy.' },
  { title: 'Nothing for sale', body: 'No commissions, no affiliate links, no products to upsell.' },
  { title: 'Your numbers stay with you', body: 'Everything you enter is saved in your own browser. There is no account and no server storing it.' },
];

export const ROADMAP: RoadmapItem[] = [
  { title: 'Goal Pace Estimator', description: 'Required savings, projected trajectory and inflation view.', status: 'live' },
  { title: 'Budgeting Help', description: '50/30/20 and custom splits, with a hand-off to your goal.', status: 'live' },
  { title: 'Wealth Tracker v1', description: 'Editable assets and liabilities with net worth and allocation.', status: 'live' },
  { title: 'Investing Education', description: 'Four starter lessons on compounding, index funds, risk and accounts.', status: 'live' },
  { title: 'Monthly budget tracker', description: 'Compare planned and actual spending, with a variable-income mode.', status: 'next' },
  { title: 'Net-worth history', description: 'Dated snapshots and a trend line.', status: 'next' },
  { title: 'Return ranges', description: 'Show best, typical and weak market outcomes instead of one rate.', status: 'next' },
  { title: 'Optional accounts', description: 'Sync your data across devices. Local-only stays the default.', status: 'later' },
  { title: 'Lesson quizzes and glossary', description: 'Short checks and a plain-English glossary.', status: 'later' },
];

export const DISCLAIMER =
  'For education only. This is not financial, tax or legal advice. Projections use simplified, constant-return assumptions and are not guarantees.';
