# Wealth

Money tools for young adults: budgeting, a net-worth tracker, plain-English investing lessons, and a goal pace estimator.
React + TypeScript + Vite + Tailwind CSS. Fully static, so it deploys to Cloudflare Pages with no server.

## Run locally

```bash
npm install
npm run dev        # http://localhost:5173
npm run build      # type-checks, then writes ./dist
npm run preview    # serve the production build
```

## Structure

```
public/            _redirects (SPA fallback), _headers, favicon
src/components/    ui/ (Button, Field, PageHeader), layout/, charts/, tools/ (one file per module)
src/pages/         Home, Tools, Philosophy, GetStarted, NotFound
src/data/          content.ts, goals.ts, lessons.ts, tools.ts  (edit copy and lessons here)
src/utils/         finance.ts (ALL financial math), format.ts
src/hooks/         useLocalStorage, useGoalInputs, useElementWidth
src/types/         shared types
```

- **Rebrand:** change `BRAND` in `src/data/content.ts`, the `<title>` in `index.html`, and the color tokens at the top of `src/index.css`.
- **Add a lesson:** append an object to `LESSONS` in `src/data/lessons.ts`.
- **Add a tool:** add an entry to `TOOLS` in `src/data/tools.ts`, create a component in `src/components/tools/`, and register it in `MODULES` in `src/pages/Tools.tsx`.
- **Waitlist emails:** set `VITE_WAITLIST_ENDPOINT` (see `.env.example`) to a URL that accepts a JSON POST `{ email, goal }`. Without it, emails are only stored in the visitor's browser.

## Deploy to Cloudflare Pages

Build command `npm run build`, output directory `dist`, environment variable `NODE_VERSION=20`.
`public/_redirects` makes client-side routes like `/tools/budgeting` work on refresh.
